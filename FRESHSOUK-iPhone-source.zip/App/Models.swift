import Foundation

struct Product: Codable, Identifiable, Equatable {
    let id: String
    let nameAr: String
    let nameFr: String
    let category: String
    let price: Decimal
    let unit: String
    let descriptionAr: String
    let descriptionFr: String
    let active: Bool?
    let available: Bool?
    let inStock: Bool?

    var isAvailable: Bool { active != false && available != false && inStock != false }
    var unitCents: Int { NSDecimalNumber(decimal: price * 100).intValue }
    var step: Double { unit.lowercased() == "kg" ? 0.5 : 1 }
    var displayUnit: String { unit.lowercased() == "kg" ? "kg" : unit }
}

struct Qoffa: Decodable, Identifiable {
    let id: String
    let fr: String
    let ar: String
    let description: String
    let descriptionAr: String
    let items: [Ingredient]
}

struct Ingredient: Codable, Equatable {
    let id: String
    let quantity: Double
}

struct Cart: Codable, Equatable {
    private(set) var quantities: [String: Double] = [:]

    mutating func add(_ product: Product, quantity: Double = 1) {
        guard product.isAvailable, quantity.isFinite, quantity > 0 else { return }
        set(product, quantity: (quantities[product.id] ?? 0) + quantity)
    }

    mutating func set(_ product: Product, quantity: Double) {
        guard quantity.isFinite else { return }
        let value = min(99, max(0, (quantity / product.step).rounded() * product.step))
        if value == 0 { quantities.removeValue(forKey: product.id) }
        else { quantities[product.id] = value }
    }

    mutating func remove(_ id: String) { quantities.removeValue(forKey: id) }
    mutating func clear() { quantities.removeAll() }
    var isEmpty: Bool { quantities.isEmpty }

    func lines(in products: [Product]) -> [CartItem] {
        products.compactMap { product in
            guard let quantity = quantities[product.id], quantity.isFinite, quantity > 0 else { return nil }
            return CartItem(product: product, quantity: quantity)
        }
    }

    func subtotal(in products: [Product]) -> Int {
        lines(in: products).reduce(0) { $0 + $1.totalCents }
    }

    func shipping(in products: [Product]) -> Int {
        let amount = subtotal(in: products)
        return amount == 0 || amount >= 20_000 ? 0 : 2_000
    }

    func total(in products: [Product]) -> Int { subtotal(in: products) + shipping(in: products) }

    func canOrder(in products: [Product]) -> Bool {
        let items = lines(in: products)
        return !items.isEmpty && items.count == quantities.count && items.allSatisfy { $0.product.isAvailable }
    }
}

struct CartItem: Identifiable {
    let product: Product
    let quantity: Double
    var id: String { product.id }
    var totalCents: Int { Int((Double(product.unitCents) * quantity).rounded()) }
}

enum Money {
    static func amount(_ cents: Int) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "fr_MA")
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        let number = NSDecimalNumber(value: cents).dividing(by: NSDecimalNumber(value: 100))
        return (formatter.string(from: number) ?? number.stringValue) + " DH"
    }

    static func quantity(_ value: Double) -> String {
        value.formatted(.number.locale(Locale(identifier: "fr_MA")).precision(.fractionLength(0...1)))
    }
}

struct CustomerRequest {
    var name = ""
    var phone = ""
    var address = ""
    var slot = "09h00 - 12h00"
    var note = ""

    private var cleanPhone: String { phone.filter { !$0.isWhitespace && $0 != "-" } }
    var isValid: Bool {
        name.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 &&
        address.trimmingCharacters(in: .whitespacesAndNewlines).count >= 5 &&
        cleanPhone.range(of: #"^(0[567][0-9]{8}|\+212[567][0-9]{8})$"#, options: .regularExpression) != nil
    }

    func message(cart: Cart, products: [Product]) -> String? {
        guard isValid, cart.canOrder(in: products) else { return nil }
        let lines = cart.lines(in: products).map {
            "• \($0.product.nameFr) / \($0.product.nameAr) — \(Money.quantity($0.quantity)) \($0.product.displayUnit) : \(Money.amount($0.totalCents))"
        }.joined(separator: "\n")
        return """
        FRESHSOUK — Demande de commande / طلب شراء
        À confirmer par FRESHSOUK / خاص تأكيد من فرش سوق

        \(lines)

        Produits / المنتجات : \(Money.amount(cart.subtotal(in: products)))
        Livraison / التوصيل : \(Money.amount(cart.shipping(in: products)))
        Total estimé / المجموع التقديري : \(Money.amount(cart.total(in: products)))
        Paiement à la livraison / الأداء عند التوصيل

        Nom / الاسم : \(name.trimmingCharacters(in: .whitespacesAndNewlines))
        Téléphone / الهاتف : \(cleanPhone)
        Casablanca / الدار البيضاء
        Adresse / العنوان : \(address)
        Créneau souhaité / الوقت المطلوب : \(slot)
        Note / ملاحظة : \(note)
        """
    }
}

enum CatalogueValidator {
    static func validate(_ products: [Product]) -> Bool {
        !products.isEmpty && products.count <= 1000 && Set(products.map(\.id)).count == products.count &&
        products.allSatisfy {
            !$0.id.isEmpty && !$0.nameFr.isEmpty && !$0.nameAr.isEmpty &&
            $0.price > 0 && $0.price <= 100_000 &&
            ["legumes", "fruits", "packs"].contains($0.category)
        }
    }
}
