import Foundation
import Combine
import Network

@MainActor final class ShopStore: ObservableObject {
    @Published private(set) var products: [Product] = []
    @Published private(set) var qoffas: [Qoffa] = []
    @Published private(set) var imageNames: [String: String] = [:]
    @Published private(set) var cart = Cart()
    @Published private(set) var favorites = Set<String>()
    @Published private(set) var online = true
    @Published private(set) var refreshing = false
    @Published private(set) var catalogueMessage = "Catalogue enregistré · الكاتالوغ المحفوظ"
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var loadError = false

    private let defaults: UserDefaults
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "freshsouk.connection")
    private let catalogueURL = URL(string: "https://sifiabdessamad09-collab.github.io/freshsouk/products.json")!

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        products = Self.decode([Product].self, resource: "products") ?? []
        qoffas = Self.decode([Qoffa].self, resource: "qoffas") ?? []
        imageNames = Self.decode([String: String].self, resource: "image-map") ?? [:]
        loadError = !CatalogueValidator.validate(products) || imageNames.isEmpty
        if let data = defaults.data(forKey: "fs.ios.catalogue"),
           let cached = try? JSONDecoder().decode([Product].self, from: data),
           CatalogueValidator.validate(cached) { products = cached }
        if let data = defaults.data(forKey: "fs.ios.cart"),
           let saved = try? JSONDecoder().decode(Cart.self, from: data) {
            // Revalidate persisted quantities; never trust malformed local state.
            for item in saved.lines(in: products) { cart.set(item.product, quantity: item.quantity) }
        }
        favorites = Set(defaults.stringArray(forKey: "fs.ios.favorites") ?? [])
        lastUpdated = defaults.object(forKey: "fs.ios.updated") as? Date
        monitor.pathUpdateHandler = { [weak self] path in
            let connected = path.status == .satisfied
            Task { @MainActor [weak self] in self?.online = connected }
        }
        monitor.start(queue: queue)
    }

    private static func decode<T: Decodable>(_ type: T.Type, resource: String) -> T? {
        guard let url = Bundle.main.url(forResource: resource, withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    var orderedProducts: [Product] {
        let lead = ["tomates", "carottes", "oranges", "oignons-rouges", "herbes", "pomme-de-terre"]
        return products.sorted {
            let a = lead.firstIndex(of: $0.id) ?? ($0.category == "packs" ? 1000 : 100)
            let b = lead.firstIndex(of: $1.id) ?? ($1.category == "packs" ? 1000 : 100)
            return a == b ? $0.nameFr < $1.nameFr : a < b
        }
    }

    func image(for product: Product) -> String? { imageNames[product.id] }
    func add(_ product: Product, quantity: Double = 1) { cart.add(product, quantity: quantity); saveCart() }
    func change(_ product: Product, quantity: Double) { cart.set(product, quantity: quantity); saveCart() }
    func remove(_ id: String) { cart.remove(id); saveCart() }
    func clearCart() { cart.clear(); saveCart() }
    private func saveCart() { defaults.set(try? JSONEncoder().encode(cart), forKey: "fs.ios.cart") }

    func toggleFavorite(_ product: Product) {
        if favorites.contains(product.id) { favorites.remove(product.id) }
        else { favorites.insert(product.id) }
        defaults.set(Array(favorites).sorted(), forKey: "fs.ios.favorites")
    }

    func qoffaItems(_ qoffa: Qoffa) -> [CartItem] {
        qoffa.items.compactMap { ingredient in
            guard let product = products.first(where: { $0.id == ingredient.id }) else { return nil }
            return CartItem(product: product, quantity: ingredient.quantity)
        }
    }
    func qoffaAvailable(_ qoffa: Qoffa) -> Bool {
        let items = qoffaItems(qoffa)
        return items.count == qoffa.items.count && items.allSatisfy { $0.product.isAvailable }
    }
    func addQoffa(_ qoffa: Qoffa) {
        guard qoffaAvailable(qoffa) else { return }
        for item in qoffaItems(qoffa) { cart.add(item.product, quantity: item.quantity) }
        saveCart()
    }

    func resetLocalData() {
        cart.clear(); favorites.removeAll()
        for key in ["fs.ios.cart", "fs.ios.favorites", "fs.ios.catalogue", "fs.ios.updated"] {
            defaults.removeObject(forKey: key)
        }
        products = Self.decode([Product].self, resource: "products") ?? []
        lastUpdated = nil
        catalogueMessage = "Données locales effacées · تمسحات المعطيات المحلية"
    }

    func refresh() async {
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }
        do {
            var request = URLRequest(url: catalogueURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  data.count < 2_000_000 else { throw URLError(.badServerResponse) }
            let updated = try JSONDecoder().decode([Product].self, from: data)
            guard CatalogueValidator.validate(updated) else { throw URLError(.cannotParseResponse) }
            products = updated
            loadError = false
            lastUpdated = Date()
            defaults.set(data, forKey: "fs.ios.catalogue")
            defaults.set(lastUpdated, forKey: "fs.ios.updated")
            catalogueMessage = "Catalogue actualisé · تحدّث الكاتالوغ"
        } catch {
            catalogueMessage = "Catalogue enregistré · الأسعار والتوفر خاصهم تأكيد"
        }
    }
}
