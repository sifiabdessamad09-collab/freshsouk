import SwiftUI
import MessageUI
import UIKit

struct CartView: View {
    @EnvironmentObject private var shop: ShopStore
    @State private var checkout = false
    @State private var confirmClear = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ConnectionNotice()
                    BilingualTitle(fr: "Votre panier", ar: "السلة ديالك")
                    if shop.cart.isEmpty {
                        ContentUnavailableView("Votre panier est vide · السلة خاوية", systemImage: "basket", description: Text("Choisissez vos produits dans le marché.\nاختار المنتجات ديالك من السوق."))
                    } else {
                        ForEach(shop.cart.lines(in: shop.products)) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(alignment: .top, spacing: 14) {
                                    if let image = shop.image(for: item.product) {
                                        Image(image).resizable().scaledToFit().frame(width: 78, height: 78)
                                    }
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(item.product.nameFr).font(.headline)
                                        Text(item.product.nameAr).font(.subheadline)
                                        Text(Money.amount(item.totalCents)).bold()
                                        if !item.product.isAvailable { Text("Indisponible · غير متوفر").font(.caption).foregroundStyle(.red) }
                                    }
                                }
                                HStack {
                                    Button { shop.change(item.product, quantity: item.quantity - item.product.step) } label: { Image(systemName: "minus.circle").frame(width: 44, height: 44) }
                                        .accessibilityLabel("Diminuer · نقص \(item.product.nameFr)")
                                    Text("\(Money.quantity(item.quantity)) \(item.product.displayUnit)").monospacedDigit()
                                    Button { shop.change(item.product, quantity: item.quantity + item.product.step) } label: { Image(systemName: "plus.circle").frame(width: 44, height: 44) }
                                        .accessibilityLabel("Augmenter · زيد \(item.product.nameFr)")
                                    Spacer()
                                    Button(role: .destructive) { shop.remove(item.id) } label: { Image(systemName: "trash").frame(width: 44, height: 44) }
                                        .accessibilityLabel("Retirer · حيد \(item.product.nameFr)")
                                }.buttonStyle(.plain)
                            }
                            Divider()
                        }
                        TotalsView()
                        Text("Livraison à Casablanca : 20 DH, offerte dès 200 DH.\nالتوصيل فالدار البيضاء: 20 درهم، مجاني من 200 درهم.").font(.footnote)
                        if !shop.cart.canOrder(in: shop.products) {
                            Text("Un produit a été retiré du catalogue ou est indisponible. Retirez-le du panier ; si nécessaire, videz le panier.\nكاين منتوج ما بقاش متوفر. حيدو من السلة؛ إلا ما بانش، فرّغ السلة.").font(.footnote).foregroundStyle(.red)
                        }
                        Button {
                            Task { await shop.refresh(); checkout = true }
                        } label: {
                            if shop.refreshing { ProgressView() }
                            else { Text("Préparer ma demande · وجد الطلب") }
                        }.buttonStyle(GoldButton()).disabled(!shop.cart.canOrder(in: shop.products) || shop.refreshing)
                        Text("Le panier reste sur cet iPhone. L’envoi d’une demande ne confirme pas la commande.\nالسلة كتبقى فهاد الآيفون. إرسال الطلب ما كيعنيش أنه تأكّد.").font(.caption).foregroundStyle(.secondary)
                        Button("Vider le panier · فرّغ السلة", role: .destructive) { confirmClear = true }.font(.footnote)
                    }
                }.padding(20).foregroundStyle(Theme.green)
            }.background(Theme.cream)
                .navigationTitle("Panier · السلة").navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: $checkout) { CheckoutView().environmentObject(shop) }
                .confirmationDialog("Vider le panier ? · نفرّغو السلة؟", isPresented: $confirmClear, titleVisibility: .visible) {
                    Button("Vider · فرّغ", role: .destructive) { shop.clearCart() }
                    Button("Annuler · رجع", role: .cancel) { }
                }
        }
    }
}

struct TotalsView: View {
    @EnvironmentObject private var shop: ShopStore
    var body: some View {
        VStack(spacing: 12) {
            totalRow("Produits · المنتجات", shop.cart.subtotal(in: shop.products))
            totalRow("Livraison · التوصيل", shop.cart.shipping(in: shop.products))
            Divider()
            totalRow("Total estimé · المجموع التقديري", shop.cart.total(in: shop.products)).bold()
        }.font(.subheadline).padding(18).background(Theme.green.opacity(0.05), in: RoundedRectangle(cornerRadius: 16))
    }
    private func totalRow(_ title: String, _ cents: Int) -> some View {
        HStack(alignment: .firstTextBaseline) { Text(title); Spacer(minLength: 12); Text(Money.amount(cents)).fixedSize() }
    }
}

private struct PreparedRequest: Identifiable {
    let id = UUID()
    let message: String
    let sms: Bool
}

struct CheckoutView: View {
    @EnvironmentObject private var shop: ShopStore
    @Environment(\.dismiss) private var dismiss
    @State private var customer = CustomerRequest()
    @State private var prepared: PreparedRequest?
    @State private var feedback = ""
    @State private var showFeedback = false
    private let slots = ["09h00 - 12h00", "12h00 - 15h00", "15h00 - 18h00", "18h00 - 21h00"]
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Préparez une demande pour FRESHSOUK. Les prix, le créneau et la livraison seront confirmés par notre équipe.\nوجد طلب لفرش سوق. الفريق غيأكد ليك الثمن والوقت والتوصيل.").font(.subheadline)
                    Text(shop.catalogueMessage).font(.caption)
                }
                Section("Vos coordonnées · المعلومات ديالك") {
                    TextField("Nom complet · الاسم الكامل", text: $customer.name).textContentType(.name)
                    TextField("Téléphone · 06XXXXXXXX", text: $customer.phone).textContentType(.telephoneNumber).keyboardType(.phonePad)
                    Text("Casablanca · الدار البيضاء")
                    TextField("Adresse complète · العنوان الكامل", text: $customer.address, axis: .vertical).textContentType(.fullStreetAddress)
                    Picker("Créneau · الوقت", selection: $customer.slot) { ForEach(slots, id: \.self) { Text($0).tag($0) } }
                    TextField("Note facultative · ملاحظة اختيارية", text: $customer.note, axis: .vertical)
                }
                Section("Récapitulatif · الملخّص") {
                    ForEach(shop.cart.lines(in: shop.products)) { item in
                        HStack(alignment: .top) {
                            Text("\(item.product.nameFr)\n\(item.product.nameAr)")
                            Spacer()
                            Text("\(Money.quantity(item.quantity)) \(item.product.displayUnit)\n\(Money.amount(item.totalCents))").multilineTextAlignment(.trailing)
                        }.font(.caption)
                    }
                    TotalsView()
                    Text("Paiement à la livraison · الأداء عند التوصيل").font(.footnote)
                }
                Section {
                    if MFMessageComposeViewController.canSendText() {
                        Button("Préparer un SMS à FRESHSOUK · وجد SMS") { prepare(sms: true) }
                            .disabled(!customer.isValid || !shop.cart.canOrder(in: shop.products))
                    }
                    Button("Partager la demande · شارك الطلب") { prepare(sms: false) }
                        .disabled(!customer.isValid || !shop.cart.canOrder(in: shop.products))
                    Text("Vérifiez le destinataire avant d’envoyer : FRESHSOUK, +212 643 880 485. Le bouton ci-dessus ouvre Messages ou le partage iPhone ; rien n’est envoyé automatiquement.\nتأكد من المرسل إليه قبل الإرسال: فرش سوق، ‎+212 643 880 485. الزر كيفتح الرسائل ولا المشاركة؛ ما كيتصيفط والو بوحدو.").font(.caption)
                    if !customer.isValid {
                        Text("Nom, adresse complète et numéro marocain 06/07/05 ou +212 requis.\nخاص الاسم والعنوان الكامل ورقم هاتف مغربي صحيح.").font(.caption).foregroundStyle(.secondary)
                    }
                } footer: {
                    Text("Vos coordonnées restent dans ce formulaire jusqu’au partage. Le panier n’est pas effacé après l’envoi. Attendez la confirmation de FRESHSOUK.\nمعلوماتك كتبقى فهاد الاستمارة حتى تختار تشاركها. السلة ما كتتمسحش من بعد الإرسال. تسنّى تأكيد فرش سوق.")
                }
            }.scrollContentBackground(.hidden).background(Theme.cream)
                .navigationTitle("Ma demande · الطلب ديالي").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Fermer · سد") { dismiss() } } }
                .sheet(item: $prepared, onDismiss: { if !feedback.isEmpty { showFeedback = true } }) { request in
                    if request.sms {
                        MessageComposer(message: request.message) { result in
                            prepared = nil
                            switch result {
                            case .sent: feedback = "SMS confié à Messages. La livraison et l’acceptation restent à confirmer par FRESHSOUK.\nالرسالة تسلّمات لتطبيق الرسائل. الوصول وقبول الطلب باقي خاصهم تأكيد من فرش سوق."
                            case .failed: feedback = "Le SMS n’a pas été envoyé. Votre panier est conservé.\nالرسالة ما تصيفطاتش. السلة باقية محفوظة."
                            default: return
                            }
                        }
                    } else { RequestShareSheet(message: request.message) }
                }
                .alert("Demande · الطلب", isPresented: $showFeedback) { Button("OK · واخا", role: .cancel) { } } message: { Text(feedback) }
        }
    }
    private func prepare(sms: Bool) {
        guard let message = customer.message(cart: shop.cart, products: shop.products) else { return }
        feedback = ""
        prepared = PreparedRequest(message: message, sms: sms)
    }
}

struct RequestShareSheet: UIViewControllerRepresentable {
    let message: String
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [message], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) { }
}

struct MessageComposer: UIViewControllerRepresentable {
    let message: String
    let completed: (MessageComposeResult) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completed: completed) }
    func makeUIViewController(context: Context) -> MFMessageComposeViewController {
        let controller = MFMessageComposeViewController()
        controller.messageComposeDelegate = context.coordinator
        controller.recipients = ["+212643880485"]
        controller.body = message
        return controller
    }
    func updateUIViewController(_ controller: MFMessageComposeViewController, context: Context) { }
    final class Coordinator: NSObject, MFMessageComposeViewControllerDelegate {
        let completed: (MessageComposeResult) -> Void
        init(completed: @escaping (MessageComposeResult) -> Void) { self.completed = completed }
        func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) { completed(result) }
    }
}
