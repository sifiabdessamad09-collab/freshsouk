import SwiftUI

@main struct FreshSoukApp: App {
    @StateObject private var shop = ShopStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(shop)
                .tint(Theme.green)
                .preferredColorScheme(.light)
        }
    }
}

enum Theme {
    static let cream = Color(red: 1, green: 0.976, blue: 0.929)
    static let green = Color(red: 0.027, green: 0.235, blue: 0.188)
    static let mustard = Color(red: 0.937, green: 0.663, blue: 0)
}

struct BilingualTitle: View {
    let fr: String
    let ar: String
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(fr).font(.system(.title2, design: .serif, weight: .bold))
            Text(ar).font(.title3).environment(\.layoutDirection, .rightToLeft)
        }.foregroundStyle(Theme.green).accessibilityElement(children: .combine)
    }
}

struct GoldButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.subheadline.bold()).padding(.horizontal, 20).padding(.vertical, 14)
            .frame(maxWidth: .infinity).foregroundStyle(Theme.green)
            .background(Theme.mustard.opacity(configuration.isPressed ? 0.7 : 1), in: Capsule())
    }
}

struct RootView: View {
    @EnvironmentObject private var shop: ShopStore
    @State private var tab = 0
    var body: some View {
        ZStack {
            HomeView(showMarket: { tab = 1 }).opacity(tab == 0 ? 1 : 0).allowsHitTesting(tab == 0).accessibilityHidden(tab != 0)
            CatalogView(favoritesOnly: false).opacity(tab == 1 ? 1 : 0).allowsHitTesting(tab == 1).accessibilityHidden(tab != 1)
            CatalogView(favoritesOnly: true).opacity(tab == 2 ? 1 : 0).allowsHitTesting(tab == 2).accessibilityHidden(tab != 2)
            CartView().opacity(tab == 3 ? 1 : 0).allowsHitTesting(tab == 3).accessibilityHidden(tab != 3)
            InfoView().opacity(tab == 4 ? 1 : 0).allowsHitTesting(tab == 4).accessibilityHidden(tab != 4)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 0) {
                Divider()
                HStack(alignment: .top, spacing: 0) {
                    tabButton(0, "Accueil", "الرئيسية", "house")
                    tabButton(1, "Marché", "السوق", "leaf")
                    tabButton(2, "Favoris", "المفضلة", "heart")
                    tabButton(3, "Panier", "السلة", "basket")
                    tabButton(4, "Infos", "معلومات", "info.circle")
                }.padding(.horizontal, 6).padding(.top, 8).padding(.bottom, 4)
            }.background(Theme.cream)
        }
        .environment(\.layoutDirection, .leftToRight)
        .task { await shop.refresh() }
    }
    private func tabButton(_ value: Int, _ fr: String, _ ar: String, _ icon: String) -> some View {
        Button { tab = value } label: {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 20, weight: tab == value ? .bold : .regular))
                    .overlay(alignment: .topTrailing) {
                        if value == 3 && !shop.cart.isEmpty {
                            Text("\(shop.cart.quantities.count)").font(.system(size: 9, weight: .bold))
                                .padding(3).background(Theme.mustard, in: Circle()).offset(x: 10, y: -7)
                        }
                    }
                Text(fr).font(.system(size: 10, weight: .semibold))
                Text(ar).font(.system(size: 10, weight: .medium))
            }.frame(maxWidth: .infinity, minHeight: 60).contentShape(Rectangle())
                .foregroundStyle(tab == value ? Theme.green : Theme.green.opacity(0.65))
        }.buttonStyle(.plain).accessibilityLabel(fr + " · " + ar)
            .accessibilityAddTraits(tab == value ? .isSelected : [])
    }
}

struct ConnectionNotice: View {
    @EnvironmentObject private var shop: ShopStore
    var body: some View {
        if !shop.online {
            Label("Hors ligne · بلا إنترنت\nLes prix et la disponibilité sont à confirmer.\nالأسعار والتوفر خاصهم تأكيد.", systemImage: "wifi.slash")
                .font(.caption).frame(maxWidth: .infinity, alignment: .leading)
                .padding(12).background(Theme.mustard.opacity(0.18)).foregroundStyle(Theme.green)
                .accessibilityAddTraits(.updatesFrequently)
        }
    }
}

struct HomeView: View {
    @EnvironmentObject private var shop: ShopStore
    let showMarket: () -> Void
    @State private var added = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    ConnectionNotice()
                    VStack(alignment: .leading, spacing: 12) {
                        Text("FRESHSOUK").font(.system(size: 34, weight: .black, design: .serif))
                        Text("Le goût du Maroc, chez vous.\nمذاق المغرب، عندكم").font(.subheadline)
                        GeometryReader { geometry in
                            Image("hero").resizable().scaledToFill()
                                .frame(width: geometry.size.width, height: 210).clipped()
                        }.frame(height: 210).clipShape(RoundedRectangle(cornerRadius: 16))
                        Text("La fraîcheur\nse partage.").font(.system(size: 40, weight: .bold, design: .serif))
                        Text("الطراوة كتجمعنا").font(.title).frame(maxWidth: .infinity, alignment: .trailing)
                        Text("Fruits et légumes frais, livrés chez vous.\nخضر وفواكه طرية حتى لباب دارك").font(.subheadline)
                        Button("Découvrir le marché · شوف السوق", action: showMarket).buttonStyle(GoldButton())
                    }.padding(.horizontal, 20)
                    BilingualTitle(fr: "Nos qoffas", ar: "القفف ديالنا").padding(.horizontal, 20)
                    ForEach(shop.qoffas) { qoffa in
                        QoffaCard(qoffa: qoffa, added: { added = true }).padding(.horizontal, 20)
                    }
                    VStack(alignment: .leading, spacing: 14) {
                        BilingualTitle(fr: "À ajouter à votre panier", ar: "زيد لقفتك")
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), alignment: .top)], spacing: 22) {
                            ForEach(Array(shop.orderedProducts.prefix(6))) { product in ProductCard(product: product) }
                        }
                        Button("Tous les produits · جميع المنتجات", action: showMarket).buttonStyle(GoldButton())
                        Text("Casablanca · الدار البيضاء\nPaiement à la livraison · خلّص ملي توصلك\nLivraison offerte dès 200 DH · التوصيل مجاني من 200 درهم")
                            .font(.footnote).lineSpacing(5)
                    }.padding(20)
                }.frame(maxWidth: .infinity, alignment: .leading).containerRelativeFrame(.horizontal).foregroundStyle(Theme.green)
            }
            .background(Theme.cream)
            .navigationTitle("FRESHSOUK").navigationBarTitleDisplayMode(.inline)
            .refreshable { await shop.refresh() }
            .alert("Ajouté au panier · تزادت للسلة", isPresented: $added) {
                Button("Continuer · كمل", role: .cancel) { }
            }
            .overlay { if shop.loadError { ContentUnavailableView("Catalogue indisponible · الكاتالوغ ما تحلش", systemImage: "exclamationmark.triangle", description: Text("Fermez puis relancez l’application. · سد التطبيق وعاود حلّو.")) } }
        }
    }
}

struct QoffaCard: View {
    @EnvironmentObject private var shop: ShopStore
    let qoffa: Qoffa
    let added: () -> Void
    var body: some View {
        VStack(spacing: 12) {
            Image(qoffa.id).resizable().scaledToFit().frame(maxHeight: 230)
            Text(qoffa.fr).font(.system(.title, design: .serif, weight: .bold))
            Text(qoffa.ar).font(.title3)
            Text(qoffa.description).font(.subheadline).multilineTextAlignment(.center)
            Text(qoffa.descriptionAr).font(.subheadline).multilineTextAlignment(.center)
            Text(Money.amount(shop.qoffaItems(qoffa).reduce(0) { $0 + $1.totalCents })).font(.title3.bold())
            Button("Choisir · اختار") { shop.addQoffa(qoffa); added() }
                .buttonStyle(GoldButton()).disabled(!shop.qoffaAvailable(qoffa))
            if !shop.qoffaAvailable(qoffa) { Text("Indisponible · غير متوفرة").font(.caption) }
            DisclosureGroup("Voir le contenu · شوف شنو فيها") {
                VStack(spacing: 10) {
                    ForEach(shop.qoffaItems(qoffa)) { item in
                        HStack(alignment: .top) {
                            VStack(alignment: .leading) { Text(item.product.nameFr); Text(item.product.nameAr) }
                            Spacer()
                            Text("\(Money.quantity(item.quantity)) \(item.product.displayUnit)")
                        }.font(.caption)
                    }
                }.padding(.top, 10)
            }.font(.footnote)
        }.padding(.bottom, 24).foregroundStyle(Theme.green)
    }
}

struct CatalogView: View {
    @EnvironmentObject private var shop: ShopStore
    let favoritesOnly: Bool
    @State private var search = ""
    @State private var category = "all"
    @State private var sort = "selection"
    private var visible: [Product] {
        let query = search.trimmingCharacters(in: .whitespacesAndNewlines)
        var list = shop.orderedProducts.filter { product in
            (!favoritesOnly || shop.favorites.contains(product.id)) &&
            (category == "all" || (category == "herbes" ? product.id == "herbes" : product.category == category)) &&
            (query.isEmpty || (product.nameFr + " " + product.nameAr).folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current).contains(query.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)))
        }
        if sort == "ascending" { list.sort { $0.unitCents < $1.unitCents } }
        if sort == "descending" { list.sort { $0.unitCents > $1.unitCents } }
        if sort == "name" { list.sort { $0.nameFr < $1.nameFr } }
        return list
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    ConnectionNotice()
                    BilingualTitle(fr: favoritesOnly ? "Mes favoris" : "Les frais du marché", ar: favoritesOnly ? "المفضلة ديالي" : "خيرات السوق")
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            categoryButton("all", "Tous", "الكل")
                            categoryButton("legumes", "Légumes", "الخضر")
                            categoryButton("fruits", "Fruits", "الفواكه")
                            categoryButton("herbes", "Herbes", "الأعشاب")
                            categoryButton("packs", "Paniers", "السلال")
                        }
                    }
                    HStack {
                        Text("\(visible.count) produits · منتوج").font(.caption)
                        Spacer()
                        Picker("Trier · ترتيب", selection: $sort) {
                            Text("Sélection · اختيارنا").tag("selection")
                            Text("Prix ↑ · الثمن طالع").tag("ascending")
                            Text("Prix ↓ · الثمن نازل").tag("descending")
                            Text("Nom · الاسم").tag("name")
                        }.pickerStyle(.menu)
                    }
                    if visible.isEmpty {
                        ContentUnavailableView(favoritesOnly ? "Aucun favori · مازال ما اخترتي والو" : "Aucun résultat · ما لقينا والو", systemImage: favoritesOnly ? "heart" : "magnifyingglass", description: Text(favoritesOnly ? "Touchez le cœur d’un produit. · ضغط على القلب ديال المنتوج." : "Essayez un autre nom ou une autre catégorie. · جرّب اسم ولا صنف آخر."))
                    }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), alignment: .top)], alignment: .leading, spacing: 24) {
                        ForEach(visible) { product in ProductCard(product: product) }
                    }
                    Text(shop.catalogueMessage).font(.caption).foregroundStyle(.secondary)
                }.padding(18).foregroundStyle(Theme.green)
            }.background(Theme.cream)
                .navigationTitle(favoritesOnly ? "Favoris · المفضلة" : "Marché · السوق")
                .navigationBarTitleDisplayMode(.inline)
                .searchable(text: $search, prompt: "Rechercher · قلب على منتوج")
                .refreshable { await shop.refresh() }
        }
    }
    private func categoryButton(_ id: String, _ fr: String, _ ar: String) -> some View {
        Button { category = id } label: {
            VStack(spacing: 3) { Text(fr); Text(ar) }.font(.caption.weight(.semibold)).padding(.horizontal, 15).padding(.vertical, 10)
                .foregroundStyle(category == id ? Theme.cream : Theme.green)
                .background(category == id ? Theme.green : Theme.green.opacity(0.05), in: Capsule())
        }.buttonStyle(.plain).accessibilityAddTraits(category == id ? .isSelected : [])
    }
}

struct ProductCard: View {
    @EnvironmentObject private var shop: ShopStore
    let product: Product
    @State private var quantity: Double = 1
    @State private var added = false
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            ZStack(alignment: .topTrailing) {
                Group {
                    if let name = shop.image(for: product) { Image(name).resizable().scaledToFit() }
                    else { Image(systemName: "leaf").resizable().scaledToFit().padding(40) }
                }.frame(height: 145).frame(maxWidth: .infinity)
                Button { shop.toggleFavorite(product) } label: {
                    Image(systemName: shop.favorites.contains(product.id) ? "heart.fill" : "heart")
                        .frame(width: 44, height: 44).background(Theme.cream.opacity(0.9), in: Circle())
                }.buttonStyle(.plain).accessibilityLabel("Favori · المفضلة : \(product.nameFr)")
                    .accessibilityValue(shop.favorites.contains(product.id) ? "Oui · نعم" : "Non · لا")
            }
            Text(product.nameFr).font(.system(.headline, design: .serif)).fixedSize(horizontal: false, vertical: true)
            Text(product.nameAr).font(.subheadline).frame(maxWidth: .infinity, alignment: .trailing).environment(\.layoutDirection, .rightToLeft)
            if product.category == "packs" {
                DisclosureGroup("Composition · شنو فيها") {
                    Text(product.descriptionFr + "\n" + product.descriptionAr).font(.caption).padding(.top, 4)
                }.font(.caption)
            }
            Text("\(Money.amount(product.unitCents)) / \(product.displayUnit)").font(.subheadline.bold())
            HStack(spacing: 2) {
                Button { quantity = max(product.step, quantity - product.step) } label: { Image(systemName: "minus").frame(minWidth: 32, minHeight: 44) }
                    .accessibilityLabel("Diminuer · نقص \(product.nameFr)")
                Text(Money.quantity(quantity)).font(.caption.monospacedDigit()).frame(minWidth: 22)
                Button { quantity = min(99, quantity + product.step) } label: { Image(systemName: "plus").frame(minWidth: 32, minHeight: 44) }
                    .accessibilityLabel("Augmenter · زيد \(product.nameFr)")
                Spacer(minLength: 0)
                Button {
                    shop.add(product, quantity: quantity)
                    added = true
                } label: {
                    Image(systemName: "basket.badge.plus").frame(width: 44, height: 44).background(Theme.mustard, in: Circle())
                }.disabled(!product.isAvailable).accessibilityLabel("Ajouter au panier · زيد للسلة \(product.nameFr)")
            }.buttonStyle(.plain)
            if added { Text("Ajouté ✓ · تزاد للسلة").font(.caption).accessibilityAddTraits(.updatesFrequently) }
            if !product.isAvailable { Text("Indisponible · غير متوفر").font(.caption) }
        }.foregroundStyle(Theme.green)
    }
}
