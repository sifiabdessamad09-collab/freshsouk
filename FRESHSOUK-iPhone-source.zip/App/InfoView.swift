import SwiftUI

struct InfoView: View {
    @EnvironmentObject private var shop: ShopStore
    @State private var clear = false
    var body: some View {
        NavigationStack {
            List {
                Section {
                    BilingualTitle(fr: "FRESHSOUK", ar: "فرش سوق")
                    Text("Le goût du Maroc, chez vous.\nمذاق المغرب، عندكم")
                    Text("Fruits, légumes et qoffas à Casablanca.\nخضر وفواكه وقفف فالدار البيضاء.")
                }
                Section("Livraison · التوصيل") {
                    Text("Casablanca · الدار البيضاء")
                    Text("20 DH · Offerte dès 200 DH\n20 درهم · مجانية من 200 درهم")
                    Text("Paiement à la livraison. Les créneaux et les prix sont à confirmer par notre équipe.\nالأداء عند التوصيل. الفريق غيأكد الوقت والثمن.")
                }
                Section("Contact · تواصل معانا") {
                    Link("Appeler · عيّط : 06 43 88 04 85", destination: URL(string: "tel:+212643880485")!)
                    Link("Le site FRESHSOUK · الموقع", destination: URL(string: "https://sifiabdessamad09-collab.github.io/freshsouk/")!)
                }
                Section("Catalogue · الكاتالوغ") {
                    Text(shop.catalogueMessage)
                    if let updated = shop.lastUpdated {
                        Text("Actualisé · آخر تحديث : \(updated.formatted(date: .abbreviated, time: .shortened))").font(.caption)
                    }
                    Button("Actualiser · حدّث") { Task { await shop.refresh() } }.disabled(shop.refreshing)
                    Text("Les photos sont intégrées à cette version. La mise à jour du catalogue peut modifier les prix et la disponibilité.\nالصور داخلة فهاد النسخة. تحديث الكاتالوغ يقدر يبدّل الثمن والتوفر.").font(.caption)
                }
                Section("Confidentialité · الخصوصية") {
                    NavigationLink("Vos données · المعطيات ديالك") { PrivacyView() }
                    Button("Effacer les données de cet iPhone · مسح المعطيات المحلية", role: .destructive) { clear = true }
                }
                Section {
                    Text("FRESHSOUK · 1.0 (1)").font(.caption)
                }
            }.scrollContentBackground(.hidden).background(Theme.cream)
                .foregroundStyle(Theme.green).navigationTitle("Infos · معلومات")
                .confirmationDialog("Effacer panier, favoris et catalogue enregistré ?\nنمسحو السلة والمفضلة والكاتالوغ المحفوظ؟", isPresented: $clear, titleVisibility: .visible) {
                    Button("Effacer · مسح", role: .destructive) { shop.resetLocalData() }
                    Button("Annuler · رجع", role: .cancel) { }
                }
        }
    }
}

struct PrivacyView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                BilingualTitle(fr: "Vos données", ar: "المعطيات ديالك")
                policy("Sur cet iPhone", "فهاد الآيفون", "Le panier, les favoris et le dernier catalogue sont enregistrés localement. Effacez-les depuis Infos > Effacer les données. Les coordonnées saisies pour une demande ne sont pas sauvegardées par l’application.", "السلة والمفضلة وآخر كاتالوغ كيتحفظو محلياً. تقدر تمسحهم من معلومات > مسح المعطيات. معلومات الاتصال اللي كتعمر فالطلب ما كيحفظهاش التطبيق.")
                policy("Mise à jour du catalogue", "تحديث الكاتالوغ", "L’application contacte le site public FRESHSOUK hébergé par GitHub Pages en HTTPS pour télécharger le catalogue. L’hébergeur peut recevoir les données techniques habituelles d’une connexion, dont l’adresse IP. Aucun nom, téléphone ou adresse de livraison n’est joint à cette requête.", "التطبيق كيتاصل بموقع فرش سوق فـGitHub Pages باش يحمّل الكاتالوغ. المستضيف يقدر يتوصل بالمعلومات التقنية ديال الاتصال بحال عنوان IP. ما كيتصيفطش مع هاد التحديث الاسم ولا الهاتف ولا عنوان التوصيل.")
                policy("Vos demandes", "الطلبات ديالك", "Vous choisissez d’ouvrir Messages ou le partage iPhone. Vérifiez le texte et le destinataire avant d’envoyer. Le service choisi applique sa propre politique. FRESHSOUK reçoit les coordonnées que vous lui envoyez pour répondre et organiser votre livraison. Pour une question ou une demande de suppression de vos messages reçus, contactez le 06 43 88 04 85.", "نتا اللي كتختار تفتح الرسائل ولا المشاركة. راجع النص والمرسل إليه قبل الإرسال. الخدمة اللي اخترتي عندها سياسة الخصوصية ديالها. فرش سوق كيتوصل بالمعلومات اللي صيفطتي باش يجاوب وينظّم التوصيل. لأي سؤال ولا طلب مسح الرسائل اللي توصل بها الفريق، تاصل بـ06 43 88 04 85.")
                policy("Permissions", "الصلاحيات", "Aucun compte, suivi publicitaire, accès aux contacts, à la caméra ou à la localisation n’est demandé. L’application n’intègre aucun SDK publicitaire ou analytique.", "ما كاين لا حساب إجباري لا تتبع إشهاري، وما كنطلبوش الكونطاكت ولا الكاميرا ولا الموقع الجغرافي. ما كاين حتى SDK ديال الإشهار ولا التحليل.")
            }.padding(20).foregroundStyle(Theme.green)
        }.background(Theme.cream).navigationTitle("Confidentialité · الخصوصية").navigationBarTitleDisplayMode(.inline)
    }
    private func policy(_ fr: String, _ ar: String, _ textFr: String, _ textAr: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(fr + " · " + ar).font(.headline)
            Text(textFr).font(.subheadline)
            Text(textAr).font(.subheadline).frame(maxWidth: .infinity, alignment: .trailing).environment(\.layoutDirection, .rightToLeft)
        }
    }
}
