# État et publication iPhone

## Statut

Sources natives préparées sur Windows. Le compte propriétaire n’a ni Mac ni Apple Developer. Ce dossier ne constitue pas une application signée ou une publication App Store. Aucun coût, inscription, contrat ou compte Apple n’a été engagé.

## À vérifier sur un environnement Apple

- Compilation Xcode et tests `swift test`, puis tests sur simulateur et iPhone réel.
- iPhone petit/grand écran, grandes tailles de texte, VoiceOver, français/arabe, clavier, champs et feuilles de partage.
- Démarrage en mode avion, retour réseau, mise à jour du catalogue, prix modifiés, produits retirés ou indisponibles.
- Panier demi-kilo, seuil 200 DH, suppression des données, favoris après relancement.
- Messages annulé/indisponible/échec, partage annulé, aucun faux message « commande confirmée ». Ne pas envoyer de demande réelle pendant les tests sans l’autorisation du commerce.

## Ce qui dépend du propriétaire avant App Store

1. Inscription Apple Developer du propriétaire, contrôle d’identité, acceptation des accords et frais annuels directement chez Apple. Un Apple ID de téléchargement ne suffit pas.
2. Réserver un bundle ID, sélectionner le Team, produire une archive signée et passer par TestFlight.
3. Confirmer le nom légal et le numéro du commerce (repris du site : +212 643 880 485). Choisir si les demandes SMS/partage conviennent au service réel, ou activer un backend de commandes avant lancement. Les créneaux et les prix restent à confirmer par l’équipe.
4. Publier une politique de confidentialité HTTPS accessible dans les métadonnées et dans l’app ; ajouter son URL finale à `PrivacyView`. Le texte intégré décrit l’implémentation actuelle, mais la durée de conservation des demandes reçues par le commerce et ses pratiques doivent être validées avant publication.
5. Remplir App Privacy avec les pratiques réelles, dont nom/téléphone/adresse, contenu des demandes et paniers transmis au commerce. Ne pas sélectionner automatiquement « aucune donnée collectée » : le commerce reçoit des demandes. Vérifier aussi le traitement technique de l’hébergeur du catalogue. Le manifeste technique ne remplace pas ces réponses.
6. Fournir screenshots pris sur la version compilée, description française/arabe, URL support, classification d’âge, zones de distribution. Aucune capture de navigateur ne doit être présentée comme capture de l’app native.
7. Déposer pour App Review. L’acceptation relève d’Apple ; pas de garantie ni délai inventé.

## Proposition de fiche (à valider)

Nom : FRESHSOUK

Sous-titre FR : Votre marché frais à Casablanca

Sous-titre AR : خيرات السوق فالدار البيضاء

Description FR : Retrouvez fruits, légumes et qoffas FRESHSOUK. Parcourez le catalogue, gardez vos favoris, composez votre panier et préparez une demande à transmettre à notre équipe. Livraison à Casablanca, paiement à la livraison. Les prix, la disponibilité et le créneau sont confirmés par FRESHSOUK. Le catalogue enregistré reste consultable sans connexion.

Description AR : لقا الخضر والفواكه والقفف ديال فرش سوق. قلّب فالمنتجات، حفظ المفضلة، وجد السلة وراجع الطلب قبل ما تصيفطو للفريق. التوصيل فالدار البيضاء والأداء عند التوصيل. فرش سوق كيأكد الثمن والتوفر والوقت. تقدر تشوف الكاتالوغ المحفوظ حتى بلا إنترنت.

Notes App Review : application native SwiftUI, aucun login, catalogue et photos intégrés, favoris et panier locaux, recherche/tri/compositions, actualisation du catalogue public. L’action de commande compose une demande ; elle ne constitue pas une commande serveur confirmée. Messages natif est facultatif et le partage iOS est disponible. Les biens sont physiques et payés à la livraison. Ne pas envoyer de demande réelle au commerce pendant la revue ; tester la composition puis annuler.

## Sources Apple consultées

- [Exigences SDK](https://developer.apple.com/news/upcoming-requirements/?id=04282026a)
- [App Review : fonctionnalités, confidentialité et biens physiques](https://developer.apple.com/app-store/review/guidelines/)
- [App Privacy et URL publique de confidentialité](https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-privacy)
- [Manifeste UserDefaults](https://developer.apple.com/documentation/technotes/tn3183-adding-required-reason-api-entries-to-your-privacy-manifest)
