import XCTest
@testable import FreshSoukCore

final class ShopTests: XCTestCase {
    func catalogue() throws -> [Product] {
        let url = try XCTUnwrap(Bundle.module.url(forResource: "products", withExtension: "json", subdirectory: "Fixtures"))
        return try JSONDecoder().decode([Product].self, from: Data(contentsOf: url))
    }
    func product(_ id: String) throws -> Product { try XCTUnwrap(try catalogue().first { $0.id == id }) }

    func testRealCatalogueAndPrices() throws {
        let products = try catalogue()
        XCTAssertEqual(products.count, 32)
        XCTAssertTrue(CatalogueValidator.validate(products))
        XCTAssertEqual(try product("pack-semaine-familial").unitCents, 18000)
        XCTAssertEqual(try product("pack-couscous-vendredi").unitCents, 4500)
        XCTAssertEqual(try product("pack-jus-fruits").unitCents, 9500)
        XCTAssertFalse(CatalogueValidator.validate(products + [products[0]]))
        XCTAssertFalse(CatalogueValidator.validate([]))
    }

    func testHalfKiloAndShippingThreshold() throws {
        let products = try catalogue()
        var cart = Cart()
        cart.add(try product("carottes"), quantity: 0.5)
        XCTAssertEqual(cart.subtotal(in: products), 325)
        XCTAssertEqual(cart.shipping(in: products), 2000)
        XCTAssertEqual(cart.total(in: products), 2325)
        cart.clear()
        cart.add(try product("tomates"), quantity: 25)
        XCTAssertEqual(cart.subtotal(in: products), 20000)
        XCTAssertEqual(cart.shipping(in: products), 0)
        cart.set(try product("tomates"), quantity: 24.5)
        XCTAssertEqual(cart.shipping(in: products), 2000)
    }

    func testQuantityRulesAndPersistence() throws {
        var cart = Cart()
        let pack = try product("pack-couscous-vendredi")
        cart.add(pack, quantity: 1.5)
        XCTAssertEqual(cart.quantities[pack.id], 2)
        cart.set(pack, quantity: .infinity)
        XCTAssertEqual(cart.quantities[pack.id], 2)
        cart.set(pack, quantity: -1)
        XCTAssertTrue(cart.isEmpty)
        cart.add(try product("tomates"), quantity: 200)
        XCTAssertEqual(cart.quantities["tomates"], 99)
        let restored = try JSONDecoder().decode(Cart.self, from: JSONEncoder().encode(cart))
        XCTAssertEqual(restored, cart)
        cart.clear()
        XCTAssertEqual(cart.shipping(in: try catalogue()), 0)
        XCTAssertFalse(cart.canOrder(in: try catalogue()))
    }

    func testRemovedAndUnavailableProductsBlockOrder() throws {
        var cart = Cart()
        let tomato = try product("tomates")
        cart.add(tomato)
        let products = try catalogue()
        XCTAssertTrue(cart.canOrder(in: products))
        XCTAssertFalse(cart.canOrder(in: products.filter { $0.id != tomato.id }))
        let unavailable = Product(id: tomato.id, nameAr: tomato.nameAr, nameFr: tomato.nameFr, category: tomato.category, price: tomato.price, unit: tomato.unit, descriptionAr: tomato.descriptionAr, descriptionFr: tomato.descriptionFr, active: true, available: false, inStock: true)
        XCTAssertFalse(cart.canOrder(in: [unavailable]))
        var empty = Cart()
        empty.add(unavailable)
        XCTAssertTrue(empty.isEmpty)
    }

    func testRequestValidationAndNoFalseConfirmation() throws {
        var request = CustomerRequest()
        request.name = "Test client"
        request.address = "Adresse fictive de test"
        request.phone = "0612345678"
        XCTAssertTrue(request.isValid)
        request.phone = "+212 6 12 34 56 78"
        XCTAssertTrue(request.isValid)
        request.phone = "1234"
        XCTAssertFalse(request.isValid)
        request.phone = "0612345678"
        var cart = Cart()
        XCTAssertNil(request.message(cart: cart, products: try catalogue()))
        cart.add(try product("carottes"), quantity: 0.5)
        let message = try XCTUnwrap(request.message(cart: cart, products: try catalogue()))
        XCTAssertTrue(message.contains("À confirmer"))
        XCTAssertTrue(message.contains("Total estimé"))
        XCTAssertTrue(message.contains("Carottes"))
        XCTAssertEqual(cart.quantities["carottes"], 0.5)
    }
}
