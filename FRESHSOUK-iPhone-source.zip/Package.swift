// swift-tools-version: 5.9
import PackageDescription

// Tests the same Foundation models compiled into the iOS app, without SwiftUI.
let package = Package(
    name: "FreshSoukCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "FreshSoukCore", targets: ["FreshSoukCore"])],
    targets: [
        .target(name: "FreshSoukCore", path: "App", exclude: ["FreshSoukApp.swift", "ShopStore.swift", "CartViews.swift", "InfoView.swift", "Assets.xcassets", "Resources", "Info.plist", "PrivacyInfo.xcprivacy"], sources: ["Models.swift"]),
        .testTarget(name: "FreshSoukCoreTests", dependencies: ["FreshSoukCore"], path: "Tests", resources: [.copy("Fixtures")])
    ]
)
