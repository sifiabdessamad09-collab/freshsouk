# FRESHSOUK pour iPhone

Projet iOS natif SwiftUI, iOS 17+, sans bibliothèque tierce. Le français et l’arabe apparaissent ensemble. Les photos et données initiales proviennent de la version FRESHSOUK approuvée ; le site publié reste indépendant.

## Contenu

- Accueil, trois qoffas, catalogue de 32 produits, catégories et recherche bilingue, tri.
- Photos intégrées, catalogue consultable dès le premier démarrage hors ligne, actualisation HTTPS des prix et disponibilités depuis le site public.
- Panier persistant, demi-kilos pour les produits au kg, favoris persistants, suppression des données locales.
- Livraison à Casablanca : 20 DH, gratuite dès 200 DH ; mêmes prix et compositions que le site au moment de la préparation.
- Formulaire natif, récapitulatif puis composition SMS adressée au commerce si Messages est disponible, ou partage iPhone. L’utilisateur doit vérifier et envoyer lui-même. Une demande reste à confirmer par FRESHSOUK ; aucun paiement ni commande réelle n’a été envoyé pendant la préparation.

Le formulaire ne sauvegarde pas le nom, le téléphone ou l’adresse dans UserDefaults. Le panier reste après composition/envoi : l’app ne peut pas vérifier réception ou acceptation. Il n’y a pas encore de serveur de commandes ni de suivi de livraison. Le backend du site n’est pas activé par ce projet.

## Ouvrir et vérifier sur Mac

1. Utiliser Xcode 26 ou ultérieur avec le SDK iOS 26 ou ultérieur (vérifier les exigences Apple avant publication).
2. Ouvrir `FreshSouk.xcodeproj`, sélectionner le schéma partagé `FreshSouk`, puis un simulateur iPhone.
3. Exécuter depuis Terminal : `bash Scripts/verify-on-mac.sh`. Le script lance `swift test`, vérifie les plist et construit pour simulateur sans signature.
4. Dans Signing & Capabilities, sélectionner le compte du propriétaire et son Team. Le bundle ID `com.freshsouk.shop` est proposé ; il faut le réserver ou en choisir un disponible. Aucune identité Apple, certificat ou clé n’est inclus.
5. Tester sur iPhone, puis Product > Archive et distribution via App Store Connect/TestFlight après inscription Apple Developer.

Le script de vérification ne fabrique pas un IPA signé et ne publie rien. Un fichier `.app` de simulateur ne s’installe pas sur un iPhone. Le projet est fourni avec ses sources ; une archive ZIP seule n’est pas un lien App Store.

Sans Mac personnel : le workflow fourni dans `.github/workflows/ios.yml` peut exécuter ces vérifications sur un runner macOS GitHub, à partir d’un dépôt contenant ce projet à sa racine. Il conserve les résultats et une capture native du simulateur. Il ne contient pas de certificat, ne signe pas et ne soumet rien à Apple.

## Contrôles avant une soumission

Voir `RELEASE.md` pour les étapes concrètes restantes : compilation et tests natifs, contrôle visuel sur iPhone, vérification du numéro commercial, choix du canal de commandes, politique de confidentialité publique et informations App Store Connect. Les tests de modèle sont dans `Tests/ShopTests.swift` et compilent le même `App/Models.swift` que l’app.

## Mettre à jour les ressources

`App/Resources/products.json` est le catalogue de secours, `qoffas.json` contient les compositions et `image-map.json` associe les produits aux images locales. Les noms/prix/disponibilités se mettent à jour depuis le site, mais les nouvelles photos nécessitent une nouvelle version. Les produits inconnus affichent une feuille neutre au lieu d’une ancienne photo incorrecte. Les produits retirés du catalogue bloquent l’envoi jusqu’à correction du panier.

Les icônes de l’interface sont SF Symbols, les photos sont les ressources FRESHSOUK approuvées. Police système et serif système : aucune police ou SDK externe. `PrivacyInfo.xcprivacy` décrit UserDefaults (CA92.1) ; les réponses App Privacy restent à compléter selon les pratiques réelles du commerce.
