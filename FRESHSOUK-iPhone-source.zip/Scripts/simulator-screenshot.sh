#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
xcrun simctl list devices available -j > .build/devices.json
DEVICE=$(python3 -c 'import json; d=json.load(open(".build/devices.json")); print(next(v["udid"] for group in d["devices"].values() for v in group if v.get("isAvailable") and v["name"].startswith("iPhone")))')
xcrun simctl boot "$DEVICE" || true
xcrun simctl bootstatus "$DEVICE" -b
xcrun simctl install "$DEVICE" .build/ios-simulator/Build/Products/Debug-iphonesimulator/FreshSouk.app
xcrun simctl status_bar "$DEVICE" override --time '9:41' --batteryState charged --batteryLevel 100
xcrun simctl launch "$DEVICE" com.freshsouk.shop
sleep 5
xcrun simctl io "$DEVICE" screenshot .build/freshsouk-iphone.png
