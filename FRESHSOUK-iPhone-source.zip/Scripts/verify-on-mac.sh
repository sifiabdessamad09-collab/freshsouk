#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This check requires a Mac with Xcode installed."
  exit 1
fi
xcodebuild -version
plutil -lint App/Info.plist App/PrivacyInfo.xcprivacy FreshSouk.xcodeproj/project.pbxproj
swift test
xcodebuild -project FreshSouk.xcodeproj -scheme FreshSouk -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' -derivedDataPath .build/ios-simulator CODE_SIGNING_ALLOWED=NO build
echo "Model tests and iOS simulator build passed. Run on an iPhone before release."
